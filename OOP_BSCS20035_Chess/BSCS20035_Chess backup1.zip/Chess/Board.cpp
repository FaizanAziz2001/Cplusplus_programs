#include "Board.h"
#include "Pawn.h"
#include"King.h"
#include"Rook.h"
#include"Bishop.h"
#include"Queen.h"
#include"Knight.h"
#include"Header.h"
#include<iostream>
#include<vector>
#include<conio.h>
#include<math.h>
#include<windows.h>
#include<vector>
using namespace std;

Board::Board()
{
	Dim = 8;
	Init();
}

void gotoRowCol(int rpos, int cpos)
{
	COORD scrn;
	HANDLE hOuput = GetStdHandle(STD_OUTPUT_HANDLE);
	scrn.X = cpos;
	scrn.Y = rpos;
	SetConsoleCursorPosition(hOuput, scrn);
}

void getRowColbyLeftClick(int& rpos, int& cpos)
{
	HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
	DWORD Events;
	INPUT_RECORD InputRecord;
	SetConsoleMode(hInput, ENABLE_PROCESSED_INPUT | ENABLE_MOUSE_INPUT | ENABLE_EXTENDED_FLAGS);
	do
	{
		ReadConsoleInput(hInput, &InputRecord, 1, &Events);
		if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
		{
			cpos = InputRecord.Event.MouseEvent.dwMousePosition.X;
			rpos = InputRecord.Event.MouseEvent.dwMousePosition.Y;
			break;
		}
	} while (true);
}

void cls()
{
	// Get the Win32 handle representing standard output.
	// This generally only has to be done once, so we make it static.
	static const HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_SCREEN_BUFFER_INFO csbi;
	COORD topLeft = { 0, 0 };

	// std::cout uses a buffer to batch writes to the underlying console.
	// We need to flush that to the console because we're circumventing
	// std::cout entirely; after we clear the console, we don't want
	// stale buffered text to randomly be written out.
	std::cout.flush();

	// Figure out the current width and height of the console window
	if (!GetConsoleScreenBufferInfo(hOut, &csbi)) {
		// TODO: Handle failure!
		abort();
	}
	DWORD length = csbi.dwSize.X * csbi.dwSize.Y;

	DWORD written;

	// Flood-fill the console with spaces to clear it
	FillConsoleOutputCharacter(hOut, TEXT(' '), length, topLeft, &written);

	// Reset the attributes of every character to the default.
	// This clears all background colour formatting, if any.
	FillConsoleOutputAttribute(hOut, csbi.wAttributes, length, topLeft, &written);

	// Move the cursor back to the top left for the next sequence of writes
	SetConsoleCursorPosition(hOut, topLeft);
}

void Board::Init()
{
	Ps = new Pieces * *[Dim] {};
	for (int ri = 0; ri < Dim; ri++)
	{
		Ps[ri] = new Pieces * [Dim] {};
		for (int ci = 0; ci < Dim; ci++)
		{
			if (ri == 1)
				Ps[ri][ci] = new Pawn(Position{ ri, ci }, BLACK, this);
			else if (ri == 6)
				Ps[ri][ci] = new Pawn(Position{ ri,ci }, WHITE, this);
			else if (ri == 0)
			{
				if (ci == 0 || ci == Dim - 1)
					Ps[ri][ci] = new Rook(Position{ ri,ci }, BLACK, this);
				else if (ci == 0 || ci == Dim - 1)
					Ps[ri][ci] = new Rook(Position{ ri,ci }, BLACK, this);
				else if (ci == 1 || ci == Dim - 2)
					Ps[ri][ci] = new Knight(Position{ ri,ci }, BLACK, this);
				else if (ci == 2 || ci == Dim - 3)
					Ps[ri][ci] = new Bishop(Position{ ri,ci }, BLACK, this);
				else if (ci == 3)
					Ps[ri][ci] = new Queen(Position{ ri,ci }, BLACK, this);
				else if (ci == 4)
					Ps[ri][ci] = new King(Position{ ri,ci }, BLACK, this);
			}
			else if (ri == Dim - 1)
			{
				if (ci == 0 || ci == Dim - 1)
					Ps[ri][ci] = new Rook(Position{ ri,ci }, WHITE, this);
				else if (ci == 0 || ci == Dim - 1)
					Ps[ri][ci] = new Rook(Position{ ri,ci }, WHITE, this);
				else if (ci == 1 || ci == Dim - 2)
					Ps[ri][ci] = new Knight(Position{ ri,ci }, WHITE, this);
				else if (ci == 2 || ci == Dim - 3)
					Ps[ri][ci] = new Bishop(Position{ ri,ci }, WHITE, this);
				else if (ci == 3)
					Ps[ri][ci] = new Queen(Position{ ri,ci }, WHITE, this);
				else if (ci == 4)
					Ps[ri][ci] = new King(Position{ ri,ci }, WHITE, this);
			}

		}
	}

}

void Board::Print_Board(char ch, int sri, int sci, char c)
{
	for (int ri = sri * Box_dim; ri < sri * Box_dim + Box_dim; ri++)
	{
		for (int ci = sci * Box_dim; ci < sci * Box_dim + Box_dim; ci++)
		{
			gotoRowCol(ri, ci);
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c);
			cout << ch;
		}
		cout << endl;
	}
}

void Board::Draw()
{
	char c = 15;
	char ch = -37;
	bool flag = true;

	for (int ri = 0; ri < 8; ri++)
	{
		for (int ci = 0; ci < 8; ci++)
		{

			c = (flag) ? 15 : 8;
			flag = !flag;
			Print_Board(ch, ri, ci, c);
			if (Ps[ri][ci] != nullptr)
			{
				Ps[ri][ci]->Draw_piece(ri, ci, c);
			}
		}
		flag = !flag;
	}

	for (int ci = Box_dim/2,a=65; ci < Dim * Box_dim ; ci=ci+Box_dim)
	{
		gotoRowCol(Dim*Box_dim+2, ci);
		cout << char(a++) << "\t\t";
	}
	for (int ri=Box_dim/2,i=Dim;ri<Dim*Box_dim;ri=ri+Box_dim)
	{
		gotoRowCol(ri,Dim*Box_dim+2);
		cout << i-- << "\t\t";
	}

}

void Board::Play()
{
	Draw();
	int counter = 1;
		Move(counter);
}

void Board::Select_Cordinates(int& ri, int& ci, int& m_ri, int& m_ci,int &counter,bool& flag)
{
	char color;
	 gotoRowCol(1, (Dim + 3) * Dim);
	 cout << "                                                       ";
	 gotoRowCol(1, (Dim + 3) * Dim);
	 cout << "Select a piece ";
	do
	{
		
		getRowColbyLeftClick(ri, ci);
		gotoRowCol(1, (Dim + 3) * Dim);
		cout << "                                                       ";
		gotoRowCol(1, (Dim + 3) * Dim);
		ri /= Box_dim;
		ci /= Box_dim;

	
		if (ri >= Dim || ci >= Dim)
			cout << "Enter valid co ordinates" ;
		else if (Ps[ri][ci] == nullptr)
			cout << "Enter valid location" ;
		else if (Ps[ri][ci]->Getcolour() != turn)
			cout << "Not your piece" ;
		else if (!Valid_Piece(ri, ci))
			cout << "Invalid Piece";
		else
		{
			
			gotoRowCol(counter, (Dim + 10) * Dim);
			cout << char('A'+ci) << (Dim-ri);
			Location.PA.push_back({ ri,ci });
			break;
		}
		
	} while (true);

	if (turn == WHITE)
		color = 15;
	else
		color = 8;
	Highlight_path(ri, ci);

	do
	{
		gotoRowCol(1, (Dim + 3) * Dim);
		cout << "Select the destination " << endl;
		getRowColbyLeftClick(m_ri, m_ci);

		m_ri /= Box_dim;
		m_ci /= Box_dim;
		if (m_ri >= Dim || m_ci >= Dim)
			cout << "Enter valid co ordinates" << endl;
		else if (Ps[m_ri][m_ci] != nullptr && Ps[m_ri][m_ci]->Getcolour() == turn)
			cout << "Your Piece already exists" << endl;
		else 
		{
			UnHighlight_path(ri, ci);
			
			break;
		}

	} while (true);


}

bool Board::Valid_Piece(int sri,int sci)
{
	Pawn* P = dynamic_cast<Pawn*>(Ps[sri][sci]);
	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			
			if (Ps[ri][ci]==nullptr&& Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }) )
				return true;
			else if (P != nullptr)
			{
				if(Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }))
					return true;
			}
		}
	}
	return false;
}

void Board::SaveBoard()
{
	Location.CB.push_back(Ps);
}

void Board::Move(int& counter)
{

	bool flag = false;
	gotoRowCol(0, (Dim + 3) * Dim);
	int ri, ci, m_ri, m_ci;

	do
	{
		SaveBoard();
		if (turn == 1)
			cout << "White Turn";
		else if (turn == 0)
			cout << "Black Turn";
		Position P = King_cordinates();
		do
		{
			Select_Cordinates(ri, ci, m_ri, m_ci, counter, flag);
			if (Ps[ri][ci]->IsLegal({ ri,ci }, { m_ri,m_ci }) && !Selfcheck({ ri,ci }, { m_ri, m_ci }))
			{
				Ps[ri][ci]->Move_Piece(m_ri, m_ci);
				Ps[m_ri][m_ci] = Ps[ri][ci];
				Ps[ri][ci] = nullptr;

				if (!My_King_check())
				{
					gotoRowCol(counter++, (Dim + 20) * Dim);
					cout << char('A' + m_ci) << (Dim - m_ri);
					Location.CA.push_back({ m_ri,m_ci });
					break;
				}
				else
				{
					Ps[m_ri][m_ci]->Move_Piece(ri, ci);
						Ps[ri][ci] = Ps[m_ri][m_ci];
						Ps[m_ri][m_ci] = nullptr;
						Location.CA.push_back({ m_ri,m_ci });
					/*Undo();*/
					
				}

			}
			else
			{
				gotoRowCol(1, (Dim + 3) * Dim);
				cout << "                                                       ";
				gotoRowCol(1, (Dim + 3) * Dim);
				cout << "Invalid Move";

			}



		} while (true);


		if (check(P))
		{

			flag = true;
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 3);
			Highlight_box({ P.ri,P.ci }, Box_dim);
			SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 15);
			/*if (checkmate(P))
			{
				return;
			}*/

		}
		ChangeTurn();
			
		
	}
	while (true);
}

void Board::ChangeTurn()
{
	if (turn == WHITE)
		turn = BLACK;
	else if (turn == BLACK)
		turn = WHITE;
}

void Board::Highlight_box(Position S, int Box_dim)
{
	char ch = -37;

	for (int ci = S.ci * Box_dim; ci < S.ci * Box_dim + Box_dim; ci++)
	{
		gotoRowCol(S.ri * Box_dim, ci);
		cout << ch;
	}

	for (int ci = S.ci * Box_dim; ci < S.ci * Box_dim + Box_dim; ci++)
	{
		gotoRowCol(S.ri * Box_dim + Box_dim - 1, ci);
		cout << ch;
	}

	for (int ri = S.ri * Box_dim; ri < S.ri * Box_dim + Box_dim; ri++)
	{
		gotoRowCol(ri, S.ci * Box_dim);
		cout << ch;
	}

	for (int ri = S.ri * Box_dim; ri < S.ri * Box_dim + Box_dim; ri++)
	{
		gotoRowCol(ri, S.ci * Box_dim + Box_dim - 1);
		cout << ch;
	}
}

void Board::Kill_Highlight(Position S, int Box_dim)
{
	char c;
	if (S.ri % 2 == 0)
	{
		if (S.ci % 2 == 0)
			c = 15;
		else
			c = 8;
	}
	else
	{
		if (S.ci % 2 == 0)
			c = 8;
		else
			c = 15;
	}
	Ps[S.ri][S.ci]->Print_onebox(S, S.ri, S.ci, Box_dim);
	Ps[S.ri][S.ci]->Draw_piece(S.ri, S.ci, c);

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
}

void Board::Kill_UnHighlight(Position S, int Box_dim, char c)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c);
	Kill_Highlight(S, Box_dim);
}

void Board::Highlight_path(int sri, int sci)
{
	char c = 15;
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 9);
	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			if (Ps[ri][ci] == nullptr)
			{
				if (Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }))
				{
					Highlight_box({ ri,ci }, Box_dim);
				}
			}
			else if (turn != Ps[ri][ci]->Getcolour())
			{
				if (Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }))
				{
					Kill_Highlight({ ri,ci }, 10);
				}

			}

		}
	}

	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

void Board::UnHighlight_path(int sri, int sci)
{
	char c;
	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			if (ri % 2 == 0)
			{
				if (ci % 2 == 0)
					c = 15;
				else
					c = 8;
			}
			else
			{
				if (ci % 2 == 0)
					c = 8;
				else
					c = 15;
			}

			if (Ps[ri][ci] == nullptr)
			{
				if (Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }))
				{
					if (Ps[ri][ci] == nullptr)
					{
						SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c);
						Ps[sri][sci]->Print_onebox({ ri,ci }, ri, ci, 10);
					}
				}

			}
			else if (turn != Ps[ri][ci]->Getcolour())
			{
				if (Ps[sri][sci]->IsLegal({ sri,sci }, { ri,ci }))
				{
					Kill_UnHighlight({ ri,ci }, 10, c);
				}
			}
		}
	}

}

int Board::GetDim()
{
	return Dim;
}



//Position Board::King_cordinates()
//{
//	Position P;
//	for (int ri = 0; ri < Dim; ri++)
//	{
//		for (int ci = 0; ci < Dim; ci++)
//		{
//			if (Ps[ri][ci]!=nullptr && turn == Ps[ri][ci]->Getcolour())
//			{
//				if (Ps[ri][ci]->GetKing())
//				{
//					P.ri = ri;
//					P.ci = ci;
//					return P;
//				}
//			}
//		}
//	}
//}

Position Board::King_cordinates()
{
	Position P{};
	King* K;
	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			if (Ps[ri][ci] != nullptr && turn != Ps[ri][ci]->Getcolour())
			{

				K = dynamic_cast<King*>(Ps[ri][ci]);
				if (K!=nullptr)
				{
					P.ri = ri;
					P.ci = ci;
					return P;
				}
			}
		}
	}
	return P;
}

bool Board::check(Position P)
{

	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			if (P.ri == ri && P.ci == ci)
				continue;
				if (Ps[ri][ci] != nullptr && Ps[ri][ci]->IsLegal({ ri,ci }, P) && turn == Ps[ri][ci]->Getcolour())
				{
					return true;
				}
		}
	}
	return false;
}

bool Board::My_King_check()
{
	ChangeTurn();
	Position S = King_cordinates();
	
		
		if (check(S))
		{
			ChangeTurn();
			return true;
		}
		ChangeTurn();

	return false;

}

bool Board::Selfcheck(Position S,Position P)
{
	King* K;
	K = dynamic_cast<King*>(Ps[S.ri][S.ci]);
	if (K == nullptr)
	{
		return false;
	}
	else
	{
		ChangeTurn();
		if (check(P))
		{
			ChangeTurn();
			return true;
		}
		ChangeTurn();
	}
	return false;
}

bool Board::checkmate(Position P)
{
	for (int ri = 0; ri < Dim; ri++)
	{
		for (int ci = 0; ci < Dim; ci++)
		{
			if (Ps[ri][ci] != nullptr)
			{
				if (Ps[P.ri][P.ci]->IsLegal({ P.ri,P.ci }, { ri,ci }) && turn == Ps[ri][ci]->Getcolour())
				{
					ChangeTurn();
					if (!Selfcheck(P, { ri,ci }))
					{
						ChangeTurn();
						return false;
					}

				}
			}
			else
			{
				if (Ps[P.ri][P.ci]->IsLegal({ P.ri,P.ci }, { ri,ci }) )
				{
					ChangeTurn();
					if (!Selfcheck(P, { ri,ci }))
					{
						ChangeTurn();
						return false;
					}
					ChangeTurn();

				}
			}
			
				
		}
	}
	return true;
}

void Board::Undo()
{

	if (Location.PA.size() <1 && Location.CA.size() <1)
		return;
	int ri, ci, m_ri, m_ci,p_ri,p_ci;


	ri = Location.PA[Location.PA.size()-1].ri;
	ci = Location.PA[Location.PA.size() - 1].ci;

	m_ri = Location.CA[Location.CA.size() - 1].ri;
	m_ci = Location.CA[Location.CA.size() - 1].ci;

	p_ri = Location.CA[Location.CA.size() - 2].ri;
	p_ci = Location.CA[Location.CA.size() - 2].ci;

	if (m_ri == p_ri || m_ci == p_ci)
	{
		auto temp = Ps[p_ri][p_ci];
	}
	Ps[m_ri][m_ci]->Move_Piece(ri, ci);
	Ps[ri][ci] = Ps[m_ri][m_ci];
	Ps[m_ri][m_ci] = nullptr;
	Location.PA.pop_back();
	Location.CA.pop_back();
}

Pieces* Board::Get(Position P)
{
	return Ps[P.ri][P.ci];
}

COLOR Board::GetTurn()
{
	return turn;
}

Board::~Board()
{

}
