#pragma once

struct Position
{
	int ri{};
	int ci{};
};


enum COLOR
{
	BLACK,WHITE
};

void gotoRowCol(int rpos, int cpos);

void getRowColbyLeftClick(int& rpos, int& cpos);





