#include"Board.h"
#include"Pieces.h"
#include<conio.h>
#include<iostream>

using namespace std;

int main()
{
    Board B;
    B.Play();
    return 0;
}


