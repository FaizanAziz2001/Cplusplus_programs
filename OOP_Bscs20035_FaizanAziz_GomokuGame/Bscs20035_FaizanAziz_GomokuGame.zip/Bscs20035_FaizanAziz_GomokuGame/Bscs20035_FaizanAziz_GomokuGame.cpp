
#include <iostream>
#include <fstream>
using namespace std;

#define capacity 100
#define maxp 10
struct board
{
	char b[capacity][capacity] = {};
	int dim;
	char Symb[maxp] = {};
	char name[maxp][capacity];
	int turn = 0, NOP;
	int WC = 0;
	int winningorder[maxp];
	int Wincount;
};

struct position
{
	int ri;
	int ci;
};

void init(board& B)
{
	ifstream fin("Grid.txt");
	fin >> B.dim;

	cout << "Number of players: ";
	cin >> B.NOP;

	for (int ri = 0; ri < B.dim; ri++)
	{
		for (int ci = 0; ci < B.dim; ci++)
			fin >> B.b[ri][ci];
	}

	for (int i = 0; i < B.NOP; i++)
	{
		cout << "Enter Player " << i + 1 << " name: ";
		cin >> B.name[i];
		cout << "Enter symbol : ";
		cin >> B.Symb[i];
	}

	cout << "Enter Win count:";
	cin >> B.Wincount;

}

void init_comp(board& B)
{
	ifstream fin("Grid.txt");
	fin >> B.dim;

	for (int ri = 0; ri < B.dim; ri++)
	{
		for (int ci = 0; ci < B.dim; ci++)
			fin >> B.b[ri][ci];
	}
	cout << "Enter Player " << 1 << " name: ";
	cin >> B.name[0];
	cout << "Enter symbol : ";
	cin >> B.Symb[0];
	cout << endl;

	cout << "Enter Bot name: ";
	cin >> B.name[1];
	cout << "Enter symbol : ";
	cin >> B.Symb[1];


	cout << "Enter Win count:";
	cin >> B.Wincount;

	B.turn = 1;
}

void display(board B)
{
	system("cls");
	for (int ri = 0; ri < B.dim; ri++)
	{
		for (int ci = 0; ci < B.dim; ci++)
			cout << B.b[ri][ci] << " ";
		cout << endl;
	}
}

void displayturnmessage(char B[], char sym)
{
	cout << B << "'s Turn " << endl << "Symbol: " << sym << endl << endl;
}

void selectposition(position& pos)
{
	cout << "Enter the row number: ";
	cin >> pos.ri;
	cout << "Enter the column number: ";
	cin >> pos.ci;

	pos.ri--;
	pos.ci--;
}

bool validation(board B, position pos)
{
	return ((pos.ri >= 0 && pos.ci >= 0) && (pos.ri < B.dim&& pos.ci < B.dim) && (B.b[pos.ri][pos.ci] == '-'));
}

void update(char b[][capacity], position pos, char sym)
{
	b[pos.ri][pos.ci] = sym;
}

void changeturn(int& num, int nop, int data[], int WC)
{

	if (num >= nop - 1)
		num = 0;
	else
		num++;

	for (int i = 0; i < WC; i++)
	{
		for (int j = 0; j < WC; j++)
		{
			if (data[j] == num)
			{
				num++;
				if (num == nop)
					num = 0;
			}

		}

	}

}

void changeturn_comp(int& num)
{

	num = (num + 1) % 2;

}

bool Hcheck(board B, int dim, position pos, char sym, int Wincount)
{
	int count = 0;
	for (int ri = 0; ri < dim; ri++)
	{
		count = 0;
		for (int ci = 0; ci < dim; ci++)
		{
			if (B.b[ri][ci] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else
				count = 0;

		}
	}
	return false;
}

bool Vcheck(board B, int dim, position pos, char sym, int Wincount)
{
	int count = 0;
	for (int ci = 0; ci < dim; ci++)
	{
		count = 0;
		for (int ri = 0; ri < dim; ri++)
		{
			if (B.b[ri][ci] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else
				count = 0;

		}
	}
	return false;
}

bool Diag1check(board B, int dim, position pos, char sym, int Wincount)
{
	int count = 0;

	for (int r = 0, ci = dim - 1; ci >= 0; r++, ci--)
	{
		int tempci = ci;
		count = 0;
		for (int ri = 0; ri < dim - r; ri++)
		{
			if (B.b[ri][tempci--] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else
				count = 0;

		}

	}

	for (int ri = 0; ri < dim; ri++)
	{
		int tempri = ri;
		count = 0;
		for (int ci = dim - 1; ci >= 0; ci--)
		{
			if (B.b[tempri++][ci] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else
				count = 0;

		}

	}


	return false;
}

bool Diag2check(board B, int dim, position pos, char sym, int Wincount)
{

	int count = 0;
	for (int ci = 0; ci < dim; ci++)
	{
		int tempci = ci;
		count = 0;
		for (int ri = 0; ri < dim - ci; ri++)
		{
			if (B.b[ri][tempci++] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else count = 0;

		}
	}

	for (int ri = 0; ri < dim; ri++)
	{
		int tempri = ri;
		count = 0;
		for (int ci = 0; ci < dim - ri; ci++)
		{
			if (B.b[tempri++][ci] == sym)
			{
				count++;
				if (count == Wincount)
					return true;
			}
			else count = 0;

		}
	}
	return false;
}

bool Wincheck(board B, position pos, char sym, int Wincount)
{
	if (Hcheck(B, B.dim, pos, sym, Wincount))
	{
		return true;

	}
	if (Vcheck(B, B.dim, pos, sym, Wincount))
	{
		return true;

	}
	if (Diag1check(B, B.dim, pos, sym, Wincount))
	{
		return true;

	}
	if (Diag2check(B, B.dim, pos, sym, Wincount))
	{
		return true;

	}
	return false;


}

void Leaderboard(board B)
{
	for (int i = 0; i < B.NOP; i++)
	{
		cout << i + 1 << ". " << B.name[B.winningorder[i]] << endl;
	}
}

void Computer_move(board B, position& P)
{
	int temp = B.Wincount;

	for (int ri = 0; ri < B.dim; ri++)
	{
		for (int ci = 0; ci < B.dim; ci++)
		{
			P.ri = ri, P.ci = ci;
			if (validation(B, P))
			{
				B.b[ri][ci] = B.Symb[B.turn];
				if (Wincheck(B, P, B.Symb[B.turn], B.Wincount))
				{

					return;
				}
				B.b[ri][ci] = '-';
			}

		}
	}

	while (B.Wincount >= 2)
	{

		for (int ri = 0; ri < B.dim; ri++)
		{
			for (int ci = 0; ci < B.dim; ci++)
			{
				P.ri = ri, P.ci = ci;
				if (validation(B, P))
				{
					B.b[ri][ci] = B.Symb[B.turn - 1];
					if (Wincheck(B, P, B.Symb[B.turn - 1], B.Wincount))
					{
						return;
					}
					B.b[ri][ci] = '-';
				}

			}
		}
		B.Wincount--;
	}


	do
	{
		P.ri = rand() % B.dim;
		P.ci = rand() % B.dim;
	} while (!validation(B, P));

}

void human()
{
	char cont;
	do
	{
		system("cls");
		int count = 0;
		board B;
		position pos;
		init(B);
		display(B);
		do
		{
			displayturnmessage(B.name[B.turn], B.Symb[B.turn]);
			do
			{
				cout << "Select the position " << endl;
				selectposition(pos);
			} while (!validation(B, pos));

			update(B.b, pos, B.Symb[B.turn]);
			display(B);

			if (Wincheck(B, pos, B.Symb[B.turn], B.Wincount))
			{
				B.winningorder[B.WC++] = B.turn;
				if (B.WC == B.NOP - 1)
				{
					changeturn(B.turn, B.NOP, B.winningorder, B.WC);
					B.winningorder[B.WC++] = B.turn;
					break;
				}
			}

			count++;

			if (count != pow(B.dim, 2))
			{
				changeturn(B.turn, B.NOP, B.winningorder, B.WC);

			}
			else if (B.WC == 1)
			{
				cout << "Game is a draw between remaining players" << endl;
				break;
			}
			else
			{
				cout << "Game is a draw" << endl;
				break;
			}



		} while (count != pow(B.dim, 2));

		cout << endl << "Leader Board: " << endl;
		Leaderboard(B);
		cout << "Do you want to continue?(Y of yes)";
		cin >> cont;
	} while (cont == 'y' || cont == 'Y');


}

void computer()
{
	char cont;

	board B;
	position pos;

	do
	{
		int count = 0;
		system("cls");
		init_comp(B);
		display(B);

		do
		{
			displayturnmessage(B.name[B.turn], B.Symb[B.turn]);
			if (B.turn == 0)
			{
				do
				{
					cout << "Select the position " << endl;
					selectposition(pos);
				} while (!validation(B, pos));
			}
			else
			{
				Computer_move(B, pos);
			}

			update(B.b, pos, B.Symb[B.turn]);
			display(B);

			if (Wincheck(B, pos, B.Symb[B.turn], B.Wincount))
			{
				cout << B.name[B.turn] << " wins" << endl;
				break;
			}

			count++;

			if (count != pow(B.dim, 2))
			{
				changeturn_comp(B.turn);

			}
			else
			{
				cout << "Game is a draw" << endl;
				break;
			}

		} while (count != pow(B.dim, 2));

		cout << "Do you want to continue?(Y of yes)";
		cin >> cont;
	} while (cont == 'y' || cont == 'Y');


}

void menu()
{
	system("cls");
	cout << "1. To play Multiplayer " << endl
		<< "2. To play with bot" << endl;
}

int main()
{
	int choice;
	char cont;
	do
	{
		menu();
		cout << "Enter number: ";
		cin >> choice;
		switch (choice)
		{
		case 1:
			human();
			break;
		case 2:
			computer();
			break;
		}
		cout << endl;
		cout << "Press you want to exit(Y for yes)?";
		cin >> cont;
	} while (cont != 'y' && cont != 'Y');

}
