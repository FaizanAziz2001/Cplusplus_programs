#pragma once
class Fraction
{
	int Num;
	int Den;
	int GCD(int Num, int Den);
	int LCM(int Num, int Den);
public:
	Fraction(int A = 0, int B = 0);
	void Init(int Num, int Den);
	Fraction Add(Fraction C);
	Fraction Sub(Fraction C);
	Fraction Mult(Fraction C);
	Fraction Div(Fraction C);
	Fraction MultInv();
	Fraction AddInv();
	void print();
};

