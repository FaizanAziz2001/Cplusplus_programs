#include <iostream>
#include"BSTree.h"
#include"BTree.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include<vector>
using namespace std;

void Sort(vector<int> data)
{
	BSTree<int> BST;
	for (int i = 0; i < data.size(); i++)
	{
		BST.Insert(data[i]);
	}

	BST.Print();
}

int main()
{
	srand(time(0));
	//BSTree<int> BST;
	//BST.Insert(7);
	//BST.Insert(3);
	//BST.Insert(5);
	//BST.Insert(2);
	//BST.Insert(10);
	//BST.Insert(9);
	//BST.Insert(11);

	BST.OutputTree();

	/*BTree<int> BT;
	BT.Insert(7);
	BT.Insert(4);
	BT.Insert(9);
	BT.Insert(3);
	BT.Insert(8);
	BT.Insert(2);
	BT.Insert(10);
	BT.Insert(11);
	BT.Insert(1);
	cout << BT.Leaves_count() << endl;
	cout << BT.Internal_Node_Count() << endl;
	BT.OutputTree();*/

	return 0;
}

