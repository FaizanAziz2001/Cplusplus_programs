#pragma once
#include<iostream>

using namespace std;
template<typename T>

class BTree
{
	class Node
	{
		T data;
		Node* left;
		Node* right;
		friend class BTree;

	private:
		Node(T d, Node* l = nullptr, Node* r = nullptr)
		{
			data = d;
			left = l;
			right = r;
		}
	};

	Node* root;

	void Print_recursion(Node* temp)
	{
		if (temp == nullptr)
			return;
		Print_recursion(temp->left);
		cout << temp->data << " ";
		Print_recursion(temp->right);
	}

	void Print_recursion_reverse(Node* temp)
	{
		if (temp == nullptr)
			return;
		Print_recursion_reverse(temp->right);
		cout << temp->data << " ";
		Print_recursion_reverse(temp->left);
	}


	bool check_trees(Node* r1, Node* r2)
	{
		if (r1 == nullptr && r2 == nullptr)
			return true;
		if (r1 == nullptr || r2 == nullptr)
			return false;
		if (r1->data != r2->data)
			return false;

		return (check_trees(r1->left, r2->left) && check_trees(r1->right, r2->right));
	}


	int Even_Count_check(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp % 2 == 0)
		{
			return (Even_Count_check(temp->left) + Even_Count_check(temp->right) + 1);
		}
		else
			return (Even_Count_check(temp->left) + Even_Count_check(temp->right));
	}

	bool check_BT_recursion(Node* temp, int max, int min)
	{
		if (temp == nullptr)
			return true;
		if (temp->data > min && temp->data < max)
			return (check_BT_recursion(temp->left, root->data, min) && check_BT_recursion(temp->right, max, root->data));
		else
			return false;

	}

	int Internal_Node_count_recursion(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp->left == nullptr && temp->right == nullptr)
			return 0;
		return (Internal_Node_count_recursion(temp->left) + Internal_Node_count_recursion(temp->right) + 1);
	}

	int Leaves_count_recursion(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp->right == nullptr && temp->left == nullptr)
			return 1;
		return (Leaves_count_recursion(temp->left) + Leaves_count_recursion(temp->right));

	}

	void OutputTree_recursion(Node* temp, int pos)
	{

		if (temp == nullptr)
			return;

		if (temp != nullptr)
		{
			OutputTree_recursion(temp->right, pos + 5);
			for (int i = 0; i < pos; i++)
			{
				cout << " ";
			}
			cout << temp->data << endl;
			OutputTree_recursion(temp->left, pos + 5);
		}
	}

public:
	class iterator
	{
		Node* i;
	public:
		iterator(Node* n)
		{
			i = n;
		}
		T operator*()
		{
			return i->data;
		}
		bool operator==(iterator n)
		{
			return i == n.i;
		}
		bool operator!=(iterator n)
		{
			return i != n.i;
		}
	};

	iterator Start()
	{
		return iterator(root);
	}

	iterator End()
	{
		return iterator(nullptr);
	}

	BTree()
	{
		root = nullptr;
	}

	void Insert(T d)
	{
		Node* temp = new Node(d);

		if (root == nullptr)
		{
			root = temp;
			return;
		}

		Node* temp2 = root;

		do
		{
		
			int ram = (rand() % 10);
			if (ram == 0 || ram==2 || ram==4 || ram==8 || ram==10)
			{
				if (temp2->left == nullptr)
				{
					temp2->left = temp;
					return;
				}
				temp2 = temp2->left;
				continue;
			}
			else 
			{
				if (temp2->right == nullptr)
				{
					temp2->right = temp;
					return;
				}
				temp2 = temp2->right;
				continue;
			}
		} while (true);
	}

	void Print()
	{
		Print_recursion(root);
	}

	void Print_reverse()
	{
		Print_recursion_reverse(root);
	}

	bool Identical_trees(BTree T2)
	{
		return check_trees(root, T2.root);
	}

	int Even_Count()
	{
		return Even_Count_check(root);
	}

	bool Check_BT()
	{
		return check_BT_recursion(root, INT_MAX, INT_MIN);
	}

	int Internal_Node_Count()
	{
		return Internal_Node_count_recursion(root);
	}

	int Leaves_count()
	{
		return Leaves_count_recursion(root);
	}

	void OutputTree()
	{
		int pos = 5;
		if (root == nullptr)
			return;
		return OutputTree_recursion(root, pos);
	}
};
