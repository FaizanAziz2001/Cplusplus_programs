#pragma once
#include<iostream>
#include <algorithm>  
#include<queue>
using namespace std;
template<typename T>

class BSTree
{

private:
	class Node
	{
		T data;
		Node* left;
		Node* right;
		Node* parent;
		friend class BSTree;

	public:
		Node(T d, Node* l = nullptr, Node* r = nullptr, Node* p = nullptr)
		{
			data = d;
			left = l;
			right = r;
			parent = p;
		}
	};

	Node* root;

	void Print_recursion(Node* temp)
	{
		if (temp == nullptr)
			return;
		Print_recursion(temp->left);
		cout << temp->data << " ";
		Print_recursion(temp->right);
	}

	void Print_recursion_reverse(Node* temp)
	{
		if (temp == nullptr)
			return;
		Print_recursion_reverse(temp->right);
		cout << temp->data << " ";
		Print_recursion_reverse(temp->left);
	}

	void OutputTree_recursion(Node* temp, int pos)
	{

		if (temp == nullptr)
			return;

		if (temp != nullptr)
		{
			OutputTree_recursion(temp->right, pos + 5);
			for (int i = 0; i < pos; i++)
			{
				cout << " ";
			}
			cout << temp->data << endl;
			OutputTree_recursion(temp->left, pos + 5);
		}
	}

	int Even_Count_check(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp->data % 2 == 0)
			return (Even_Count_check(temp->left) + Even_Count_check(temp->right) + 1);
		else
			return (Even_Count_check(temp->left) + Even_Count_check(temp->right));


	}

	int Tree_Height_check(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		return max(Tree_Height_check(temp->left), Tree_Height_check(temp->right)) + 1;
	}

	int Internal_Node_count_recursion(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp->left == nullptr && temp->right == nullptr)
			return 0;
		return (Internal_Node_count_recursion(temp->left) + Internal_Node_count_recursion(temp->right) + 1);
	}

	int Leaves_count_recursion(Node* temp)
	{
		if (temp == nullptr)
			return 0;
		if (temp->right == nullptr && temp->left == nullptr)
			return 1;
		return (Leaves_count_recursion(temp->left) + Leaves_count_recursion(temp->right));

	}

	bool check_BST_recursion(Node* temp, int max, int min)																							//left node needs to be less than parent and greater than its child
	{
		if (temp == nullptr)																														//right node needs to be greater than parent and less than its child 
			return true;
		if (temp->data > min && temp->data < max)																										//max determines upper bound and min lower bound
			return (check_BST_recursion(temp->left, temp->data, min) && check_BST_recursion(temp->right, max, temp->data));
		else
			return false;

	}

	bool check_trees(Node* r1, Node* r2)
	{
		if (r1 == nullptr && r2 == nullptr)
			return true;
		if (r1 == nullptr || r2 == nullptr)
			return false;
		if (r1->data != r2->data)
			return false;

		return (check_trees(r1->left, r2->left) && check_trees(r1->right, r2->right));
	}

	static Node* Min(Node* temp)
	{
		while (temp->left != nullptr)				//static so it can be called in iterator
			temp = temp->left;
		return temp;
	}

	static Node* Max(Node* temp)
	{
		while (temp->right != nullptr)
			temp = temp->right;
		return temp;
	}

	static Node* Successor(Node* r)
	{
		if (r->right != nullptr)
		{
			return Min(r->right);
		}
		while (r->parent != nullptr && r->parent->right == r)
			r = r->parent;
		return r->parent;
	}

	static Node* Predecessor(Node* r)
	{
		if (r->left != nullptr)
		{
			return Max(r->left);
		}
		while (r->parent != nullptr && r->parent->left == r)
			r = r->parent;
		return r->parent;
	}


public:
	class iterator
	{
		Node* i;

	public:
		iterator(Node* n)
		{
			i = n;
		}
		T operator*()
		{
			return i->data;
		}
		bool operator==(iterator n)
		{
			return i == n.i;
		}
		bool operator!=(iterator n)
		{
			return i != n.i;
		}
	};

	class LNR_iterator
	{
		Node* i;
		friend class BSTree;

		/*void Successor()
		{
			if (i->right != nullptr)
			{
				i = BSTree::Min(i->right);
				return;
			}

			while (i->parent->right == i)
				i = i->parent;
			i = i->parent;
		}

		void Predecessor()
		{
			if (i->left != nullptr)
			{
				i = BSTree::Max(i->left);
				return;
			}
			while (i->parent->right == i)
				i = i->parent;
			i = i->parent;
		}*/

	public:
		LNR_iterator(Node* n)
		{
			i = n;
		}

		T operator*()
		{
			return i->data;
		}

		LNR_iterator operator++()
		{
			i = Successor(i);
			return *this;
		}

		LNR_iterator operator--()
		{

			i = Predecessor(i);
			return *this;
		}

		bool operator==(LNR_iterator n)
		{
			return i == n.i;
		}

		bool operator!=(LNR_iterator n)
		{
			return i != n.i;
		}
	};

	iterator Start()
	{
		return iterator(root);
	}

	iterator End()
	{
		return iterator(nullptr);
	}

	iterator Search(T val)
	{
		Node* temp = root;
		if (val == root->data)
		{
			return iterator(temp);
		}

		while (temp != nullptr)
		{
			if (temp->data == val)
				return temp;
			else if (temp->data > val)
				temp = temp->left;
			else
				temp = temp->right;
		}

		return iterator(temp);
	}

	LNR_iterator LNR_Start()
	{
		return Min(root);
	}

	LNR_iterator LNR_End()
	{
		return Max(root);
	}

	BSTree()
	{
		root = nullptr;
	}

	void Insert(T d)
	{
		Node* temp = new Node(d);

		if (root == nullptr)
		{
			root = temp;
			root->parent = nullptr;
			return;
		}

		Node* temp2 = root;
		do
		{
			if (temp2->data > d)
			{
				if (temp2->left == nullptr)
				{
					temp2->left = temp;
					temp->parent = temp2;
					return;
				}

				temp2 = temp2->left;
			}
			else
			{
				if (temp2->right == nullptr)
				{
					temp2->right = temp;
					temp->parent = temp2;
					return;
				}

				temp2 = temp2->right;
			}

		} while (true);
	}

	void Print()
	{
		Print_recursion(root);
	}

	void OutputTree()
	{
		int pos = 5;
		if (root == nullptr)
			return;
		return OutputTree_recursion(root, pos);
	}

	void Print_reverse()
	{
		Print_recursion_reverse(root);
	}

	int Even_Count()
	{
		return Even_Count_check(root);
	}

	int Tree_height()
	{
		return Tree_Height_check(root);
	}

	int Internal_Node_Count()
	{
		return Internal_Node_count_recursion(root);
	}

	int Leaves_count()
	{
		return Leaves_count_recursion(root);
	}

	bool Check_BST()
	{
		return check_BST_recursion(root, INT_MAX, INT_MIN);
	}

	bool Identical_trees(BSTree T2)
	{
		return check_trees(root, T2.root);
	}
};
