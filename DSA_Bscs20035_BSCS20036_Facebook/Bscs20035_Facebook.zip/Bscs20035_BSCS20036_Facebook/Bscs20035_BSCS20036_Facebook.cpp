#include"Facebook.h"
#include <iostream>
using namespace std;

int main()
{
	Facebook FB;
	FB.Run();
	return 0;
}

