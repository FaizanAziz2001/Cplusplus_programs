
#include"Dos.h"
#include"TextEditor.h"
#include <iostream>
using namespace std;

int main()
{
    Dos D;
    D.Run();
    return 0;
}

