#include <iostream>
#include"FileCompressor.h"
using namespace std;

int main()
{
    FileCompressor F;
    F.Compress();
}
