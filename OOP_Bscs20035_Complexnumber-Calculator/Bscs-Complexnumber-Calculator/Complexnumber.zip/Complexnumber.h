#pragma once
class Complexnumber
{
	float real;
	float imaginary;

public:
	Complexnumber(float r = 0, float i = 0);
	void Init(float r, float i);
	void print();
	Complexnumber Add(Complexnumber C);
	Complexnumber Sub(Complexnumber C);
	Complexnumber Mult(Complexnumber C);
	Complexnumber Div(Complexnumber C);
	Complexnumber AddInv();
	Complexnumber Inv();
	Complexnumber Conj();
	void Mod();

};

